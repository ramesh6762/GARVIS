command_info = ['who are you', 'what is your name',
                'what are you', 'tell me about yourself']
info = ['Sir, i am your desktop assistant, My name is walter. What can i do for you',
        'sir, I am walter. Your desktop assistant. Happy to see you.']

command_greet = ['hello walter',
                 'are you there walter', 'are you there', 'hello']
greet = ['Hello sir, how may i help you?',
         'Hello sir, I am here for your help', 'Yes sir, how may i help you']

command_quit = ['close the program', 'quit the program', 'terminate the program', 'exit the program'
                'close program', 'quit program', 'terminate program', 'exit program', 'quit', 'exit', 'terminate yourself']
command_quit_replay = ['Closing the program', 'Quiting the program',
                       'Terminating the program', 'Exiting the program']

chat_1 = ['good morning walter', 'morning walter', 'good morning']
chat_1_replay = ['Good morning sir. I hope your day will be good',
                 'Good morning sir, how may i help you?', 'Good morinng sir, happy to see you again']

chat_2 = ['thankyou walter', 'thank you',
          'good job', 'good job walter', 'nice job']
chat_2_replay = ['Your welcome sir.', 'My pleasure.', 'Happy to help, sir']

chat_3 = ['you are an idiot', 'what had you done', "are you crazy",
          "shut up", 'you are stupid', 'are you an idiot', 'you are idiot']
chat_3_replay = ['Sorry sir, I apologize',
                 'Sorry sir, I am still learning.', 'Sorry sir']

chat_4 = ['nice work', 'nice work walter', 'good work', "it's awesome"]
chat_4_replay = ['Thank you sir.',
                 'Nice to hear from you sir.', 'My pleasure to help you.']

chat_5 = ['how are you']
chat_5_replay = ['I am fine sir,what about you']

chat_6 = ['i am fine', 'thanks for asikng']
chat_6_replay = ['Oh! nice to hear from you sir']

chat_7 = ['good afternoon walter', 'good afternoon']
chat_7_replay = ['Sir,I hope your day will be good',
                 'Sir, how may i help you?', 'Sir, happy to see you again']

chat_8 = ['how can you help me', 'why i should take your help']
chat_8_replay = ['Sir, i am a your assistant having various features',
                 'Sir, i can automate your variously done daily tasks']

chat_9 = ['who created you', 'who is your creator']
chat_9_replay = [
    'Sir, i am created by students of Indian Institute of Information and Technology Dharwad',
    'Sir, i am a Python project created by students of Indian Institute of Information and Technology Dharwad']

chat_10 = ['what can you do', 'what are your features',
           'what can you do for me', 'what are your functionality']
chat_10_replay = ['Sir, I can do most of the tasks like showing weather, sending mails, joining meet for you ,taking screenshots,playing music, Opening your social network and many more. You can ask me anything.',
                  'Sir, I can follow your commands to do stuffs like sending mails, joining meet, Opening apps or websites, finding answers from internet. I can tell you weather, Wiki bio etc. You can ask me anything.',
                  'Sir, i can do tasks like showing weather, finding any place,launching any applications like notepad,chrome,firefox etc., tell jokes etc. You can ask me anything.']

chat_11 = ['why are you created']
chat_11_replay = ['Sir, i am created to make your daily tasks easy']
